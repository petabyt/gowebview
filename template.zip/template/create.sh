#!/bin/bash
echo Input app name \(My Epic App\)
read appname
echo Input app ID \(com.mojang.minecraft\)
read appid
echo Replacing...
grep -rl  . | parallel sed -i 's//$appname/g' {}
grep -rl  . | parallel sed -i 's//$appid/g' {}
echo Done.